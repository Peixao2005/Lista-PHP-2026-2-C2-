<?php 
include("main.html");

$numero1 = $_GET["numero1"];

if ($numero1 > 0){
    echo "Seu número é POSITIVO";
}
else if ($numero1 < 0){
    echo "Seu número é NEGATIVO";
}
else{
    echo "Seu número é ZERO";
}
?>