<?php 
include("temp.html");

$temperatura = $_GET("temperatura");

$temperatura2 = $temperatura * 9/5 + 32;

echo "$temperatura2"

    

?>