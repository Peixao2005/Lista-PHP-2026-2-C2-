<?php
$c = readline("Celsius: ");
$f = (9/5) * $c + 32;
echo $f;
?>
